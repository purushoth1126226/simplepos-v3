<?php $__env->startSection('headSection'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminnavbar'); ?>
    <?php if (isset($component)) { $__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5 = $component; } ?>
<?php $component = App\View\Components\Admin\Layouts\Adminnavbar::resolve(['modulename' => ''.e(__('USER SETTINGS')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layouts.adminnavbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Layouts\Adminnavbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5)): ?>
<?php $component = $__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5; ?>
<?php unset($__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if (isset($component)) { $__componentOriginalc37512d89d4364a9200437d4882f3597 = $component; } ?>
<?php $component = App\View\Components\Admin\Layouts\Adminbreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layouts.adminbreadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Layouts\Adminbreadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a class="text-decoration-none"
                href="<?php echo e(route('adminsettings')); ?>"><?php echo e(__('Settings')); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('User')); ?></li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc37512d89d4364a9200437d4882f3597)): ?>
<?php $component = $__componentOriginalc37512d89d4364a9200437d4882f3597; ?>
<?php unset($__componentOriginalc37512d89d4364a9200437d4882f3597); ?>
<?php endif; ?>

    <?php echo $__env->make('admin.settings.user.partial', ['name' => 'adduser', 'col' => 'col-sm-6'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.settings.user.user.userlivewire');

$__html = app('livewire')->mount($__name, $__params, 'uxZL6PQ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footerSection'); ?>
    <?php echo $__env->make('helper.sidenavhelper.sidenavactive', [
        'type' => 1,
        'nameone' => '#adminsettings_sidenav',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin.layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/starpos_feedback_web/resources/views/admin/settings/user/user/usercreateoredit.blade.php ENDPATH**/ ?>