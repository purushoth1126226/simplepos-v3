<?php $__env->startSection('headSection'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminnavbar'); ?>
    <?php if (isset($component)) { $__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5 = $component; } ?>
<?php $component = App\View\Components\Admin\Layouts\Adminnavbar::resolve(['modulename' => 'SETTINGS'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layouts.adminnavbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Layouts\Adminnavbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5)): ?>
<?php $component = $__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5; ?>
<?php unset($__componentOriginal717da8ed2e9b7f7879f617a6cdd020c5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if (isset($component)) { $__componentOriginalc37512d89d4364a9200437d4882f3597 = $component; } ?>
<?php $component = App\View\Components\Admin\Layouts\Adminbreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layouts.adminbreadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Layouts\Adminbreadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item active" aria-current="page">
            Settings
        </li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc37512d89d4364a9200437d4882f3597)): ?>
<?php $component = $__componentOriginalc37512d89d4364a9200437d4882f3597; ?>
<?php unset($__componentOriginalc37512d89d4364a9200437d4882f3597); ?>
<?php endif; ?>

    <div class="p-2">
        <?php echo $__env->make('admin.settings.settings.mastersettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.settings.settings.usersettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.settings.settings.generalsettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.settings.settings.locationsettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.settings.settings.supportsettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.settings.settings.notificationsettings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footerSection'); ?>
    <?php echo $__env->make('helper.sidenavhelper.sidenavactive', [
        'type' => 1,
        'nameone' => '#adminsettings_sidenav',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin.layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/simpleposv3/resources/views/admin/settings/settings/settings.blade.php ENDPATH**/ ?>