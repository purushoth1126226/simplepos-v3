<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuestionlistController extends Controller
{
    //
}
