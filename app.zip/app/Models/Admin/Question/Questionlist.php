<?php

namespace App\Models\Admin\Question;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Questionlist extends Model
{
    use HasFactory;
}
