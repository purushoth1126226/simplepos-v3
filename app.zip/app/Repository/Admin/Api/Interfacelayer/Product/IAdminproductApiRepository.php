<?php

namespace App\Repository\Admin\Api\Interfacelayer\Product;

interface IAdminproductApiRepository
{
    public function adminsearchproduct();

    public function adminoverallproductsearch();

}
