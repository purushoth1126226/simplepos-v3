<?php

namespace App\Repository\Admin\Api\Interfacelayer\Notification;

interface IAdminnotificationApiRepository
{
    public function adminnotification();

}
