<?php

namespace App\Repository\Admin\Api\Interfacelayer\Support;

interface IAdminsupportApiRepository
{
    public function adminsupport();

}
