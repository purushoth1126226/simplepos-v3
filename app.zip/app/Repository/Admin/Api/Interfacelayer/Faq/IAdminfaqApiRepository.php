<?php

namespace App\Repository\Admin\Api\Interfacelayer\Faq;

interface IAdminfaqApiRepository
{
    public function adminfaq();

}
