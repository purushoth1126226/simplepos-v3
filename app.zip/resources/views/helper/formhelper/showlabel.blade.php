<div class="row {{ $columnone }} p-1">
    <label class="fw-bolder {{ $columntwo }}">{{ $name }} </label>
    <label class="fst-normal text-break  {{ $columnthree }}"><b> : </b> {!! $value !!}</label>
</div>
