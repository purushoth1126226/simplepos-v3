<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title> {{ config('app.name', '8Queens') }}</title>
<link rel="icon" href="/logo/logo.png" type="image/x-icon">
<link rel="shortcut icon" href="/logo/logo.png" type="image/x-icon">
